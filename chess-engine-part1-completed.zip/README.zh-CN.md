# Chess Engine Part 1 使用与学习说明

这份项目保留 starter 的头文件接口和 `ARTEMIS_TESTING` 条件编译标记，实现作业的 Task 1-6。
本地测试是补充检查，不能代表 Artemis 隐藏测试或最终成绩。

## 先看棋盘初始化与打印

从 `src/board_io.cpp` 的前两个函数开始阅读。

- `Board` 是 8 行、每行 8 格的数组，访问方式是 `board[row][col]`。
- 第 0 行是第 8 横排；第 7 行是第 1 横排。第 0 列是 a 列。
- `initBoard()` 先将每行填成 `Piece::Empty`，再设置双方底线和兵。
  因此，对已经走过棋的棋盘再次调用它，也会恢复初始状态。
- `for (auto& row : board)` 中的 `&` 表示引用，修改的是棋盘里的那一行。
- `printBoard()` 从第 0 行向下遍历，输出行号 `8 - row`，通过已有的
  `PieceUnicode.at(piece)` 取得棋子符号。每格后有一个空格，每行结束有换行；
  最后一行是两个前导空格加 `a b c d e f g h`。
- 参数 `const Board&` 表示直接读取原棋盘，同时禁止函数修改它。

## 其余功能在哪里

| 功能 | 文件与处理方式 |
| --- | --- |
| 棋子字符、颜色、敌我查询 | `src/board_io.cpp`，白方字符大写，黑方字符小写，空格用 `.` |
| 坐标转换 | `src/board_io.cpp`，例如 `e2` 对应 `{6, 4}` |
| FEN | `src/board_io.cpp`，只读写棋子布局；导入时忽略后面五个字段 |
| 解析和执行移动 | `src/uci.cpp`，读取起点、终点和可选的升变字符 |
| UCI 命令 | `src/uci.cpp`，处理握手、准备、重置、局面、显示和占位走棋回复 |
| 输入循环与退出 | `src/main.cpp`，逐行读取输入，遇到 `quit` 退出 |

升变时，UCI 的 `q/r/b/n` 始终小写，但放上棋盘的棋子颜色由移动前的棋子决定。
Part 1 按要求直接执行给定的普通移动与升变；不实现合法走棋检查、王车易位、吃过路兵或搜索算法。
`go` 返回作业要求的 `bestmove 0000`。

对于没有规定行为的错误输入，这份实现将非法坐标设为 `{-1, -1}`，忽略无法解析的移动；
FEN 只有在八行均完整且字符合法时才替换棋盘，避免留下只加载了一半的局面。

## 编译和测试

需要支持 C++20 的编译器和 CMake。使用自己配置好的工具链时，在项目目录运行：

```text
cmake -S . -B build
cmake --build build --config Debug
ctest --test-dir build -C Debug --output-on-failure
```

测试在 `tests/assignment_tests.cpp` 中，分为六组：棋盘与准确打印、棋子转换与查询、
坐标、FEN、移动、UCI。包括全部 64 个坐标、双方四种升变以及 100 个随机棋盘的 FEN 往返转换。
测试使用显式检查，Release 编译也会执行检查。

当前工作区另外提供 `../check-chess.ps1`，使用旁边 `build-tools` 中的便携工具：

```powershell
& 'F:\ChatGPT\av p\check-chess.ps1'
```

该脚本只在当前进程设置工具路径，并生成可以直接运行的 `build/assignment_main.exe`。
便携工具和本地检查脚本不包含在可分享的源码 ZIP 中。

## 手动运行作业示例

运行编译后的 `assignment_main`。Windows 的具体路径依编译器而定；
当前便携工具生成的程序位于 `build/assignment_main.exe`，Visual Studio 通常放在 `build/Debug/`。

依次输入：

```text
uci
isready
position startpos moves e2e4 e7e5 g1f3 b8c6
d
go
stop
quit
```

应看到 `uciok`、`readyok`、四步之后的棋盘以及 `bestmove 0000`。
程序启动时不会主动打印棋盘，需要输入 `d` 或 `display`。
如果 Windows 终端的棋子显示乱码，可先在该终端运行 `chcp 65001`，并使用支持国际象棋符号的字体。

## 提交到 Artemis

下载的 starter ZIP 不含 Git 历史，这个工作副本没有连接你的远程仓库。
本地检查不会自动提交作业。

在本机已认证的 Git 客户端中克隆自己的作业仓库，将修改后的 `CMakeLists.txt`、
`src/board_io.cpp`、`src/uci.cpp` 和新增的 `tests/assignment_tests.cpp` 复制进去，
按课程流程提交并推送，再到 Artemis 查看测试结果。保留 `include/` 下的原有接口和
`src/main.cpp` 中的 `ARTEMIS_TESTING` 标记。

不要把访问令牌写入项目文件、命令或聊天消息。
