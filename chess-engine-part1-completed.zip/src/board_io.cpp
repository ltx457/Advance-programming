#include "board_io.h"
#include <cctype>
#include <iostream>
#include <sstream>

void initBoard(Board& board) {
  for (auto& row : board) {
    row.fill(Piece::Empty);
  }

  board[0] = {Piece::BRook, Piece::BKnight, Piece::BBishop, Piece::BQueen,
              Piece::BKing, Piece::BBishop, Piece::BKnight, Piece::BRook};
  board[1].fill(Piece::BPawn);
  board[6].fill(Piece::WPawn);
  board[7] = {Piece::WRook, Piece::WKnight, Piece::WBishop, Piece::WQueen,
              Piece::WKing, Piece::WBishop, Piece::WKnight, Piece::WRook};
}

void printBoard(const Board& board) {
  for (int row = 0; row < 8; ++row) {
    std::cout << 8 - row << ' ';
    for (Piece piece : board[row]) {
      std::cout << PieceUnicode.at(piece) << ' ';
    }
    std::cout << '\n';
  }
  std::cout << "  a b c d e f g h\n";
}

char pieceToChar(Piece piece) {
  switch (piece) {
    case Piece::WPawn: return 'P';
    case Piece::WKnight: return 'N';
    case Piece::WBishop: return 'B';
    case Piece::WRook: return 'R';
    case Piece::WQueen: return 'Q';
    case Piece::WKing: return 'K';
    case Piece::BPawn: return 'p';
    case Piece::BKnight: return 'n';
    case Piece::BBishop: return 'b';
    case Piece::BRook: return 'r';
    case Piece::BQueen: return 'q';
    case Piece::BKing: return 'k';
    default: return '.';
  }
}

Piece charToPiece(char c) {
  switch (c) {
    case 'P': return Piece::WPawn;
    case 'N': return Piece::WKnight;
    case 'B': return Piece::WBishop;
    case 'R': return Piece::WRook;
    case 'Q': return Piece::WQueen;
    case 'K': return Piece::WKing;
    case 'p': return Piece::BPawn;
    case 'n': return Piece::BKnight;
    case 'b': return Piece::BBishop;
    case 'r': return Piece::BRook;
    case 'q': return Piece::BQueen;
    case 'k': return Piece::BKing;
    default: return Piece::Empty;
  }
}

Color getPieceColor(Piece piece) {
  if (isWhitePiece(piece)) {
    return Color::White;
  }
  if (isBlackPiece(piece)) {
    return Color::Black;
  }
  return Color::None;
}

bool isWhitePiece(Piece piece) {
  return piece >= Piece::WPawn && piece <= Piece::WKing;
}

bool isBlackPiece(Piece piece) {
  return piece >= Piece::BPawn && piece <= Piece::BKing;
}

bool isOpponent(Piece p1, Piece p2) {
  const Color first = getPieceColor(p1);
  const Color second = getPieceColor(p2);
  return first != Color::None && second != Color::None && first != second;
}

std::string squareToString(Square sq) {
  if (!isValidSquare(sq)) {
    return "";
  }
  return {static_cast<char>('a' + sq.col), static_cast<char>('8' - sq.row)};
}

Square stringToSquare(const std::string& str) {
  if (str.size() != 2 || str[0] < 'a' || str[0] > 'h' || str[1] < '1' ||
      str[1] > '8') {
    return Square{-1, -1};
  }
  return Square{'8' - str[1], str[0] - 'a'};
}

bool isValidSquare(Square sq) {
  return sq.row >= 0 && sq.row < 8 && sq.col >= 0 && sq.col < 8;
}

void loadFen(Board& board, const std::string& fen) {
  Board parsed{};
  std::istringstream input(fen);
  std::string placement;
  input >> placement;
  int row = 0;
  int col = 0;

  // Parse into a temporary board so malformed input cannot leave a partial board.
  for (char c : placement) {
    if (c == '/') {
      if (col != 8 || row == 7) {
        return;
      }
      ++row;
      col = 0;
    } else if (c >= '1' && c <= '8') {
      col += c - '0';
      if (col > 8) {
        return;
      }
    } else {
      const Piece piece = charToPiece(c);
      if (piece == Piece::Empty || col >= 8) {
        return;
      }
      parsed[row][col++] = piece;
    }
  }

  if (row == 7 && col == 8) {
    board = parsed;
  }
}

std::string boardToFen(const Board& board) {
  std::ostringstream output;
  for (int row = 0; row < 8; ++row) {
    int emptyCount = 0;
    for (Piece piece : board[row]) {
      if (piece == Piece::Empty) {
        ++emptyCount;
      } else {
        if (emptyCount != 0) {
          output << emptyCount;
          emptyCount = 0;
        }
        output << pieceToChar(piece);
      }
    }
    if (emptyCount != 0) {
      output << emptyCount;
    }
    if (row != 7) {
      output << '/';
    }
  }
  return output.str();
}
