#include "uci.h"
#include "board_io.h"
#include <cctype>
#include <iostream>
#include <sstream>

Move parseMove(const std::string& moveStr) {
  const Move invalid{Square{-1, -1}, Square{-1, -1}, Piece::Empty};
  if (moveStr.size() != 4 && moveStr.size() != 5) {
    return invalid;
  }

  Move move{stringToSquare(moveStr.substr(0, 2)),
            stringToSquare(moveStr.substr(2, 2)), Piece::Empty};
  if (!isValidSquare(move.from) || !isValidSquare(move.to)) {
    return invalid;
  }
  if (moveStr.size() == 5) {
    const char promotion = static_cast<char>(
        std::tolower(static_cast<unsigned char>(moveStr[4])));
    if (promotion != 'q' && promotion != 'r' && promotion != 'b' && promotion != 'n') {
      return invalid;
    }
    move.promotion = charToPiece(promotion);
  }
  return move;
}

std::string moveToString(const Move& move) {
  if (!isValidSquare(move.from) || !isValidSquare(move.to)) {
    return "";
  }
  std::string result = squareToString(move.from) + squareToString(move.to);
  if (move.promotion != Piece::Empty) {
    result += static_cast<char>(
        std::tolower(static_cast<unsigned char>(pieceToChar(move.promotion))));
  }
  return result;
}

void applyMove(Board& board, const Move& move) {
  if (!isValidSquare(move.from) || !isValidSquare(move.to) || move.from == move.to) {
    return;
  }

  Piece piece = board[move.from.row][move.from.col];
  if (piece == Piece::Empty) {
    return;
  }
  if (move.promotion != Piece::Empty) {
    char promotion = static_cast<char>(
        std::tolower(static_cast<unsigned char>(pieceToChar(move.promotion))));
    if (promotion != 'q' && promotion != 'r' && promotion != 'b' && promotion != 'n') {
      return;
    }
    // UCI promotion letters are lowercase even when a White pawn promotes.
    if (isWhitePiece(piece)) {
      promotion = static_cast<char>(
          std::toupper(static_cast<unsigned char>(promotion)));
    }
    piece = charToPiece(promotion);
  }
  board[move.to.row][move.to.col] = piece;
  board[move.from.row][move.from.col] = Piece::Empty;
}

void handleUciCommand(const std::string& line, Board& board) {
  std::istringstream input(line);
  std::string command;
  input >> command;

  if (command == "uci") {
    std::cout << "id name MyChessEngine\nid author Student\nuciok\n" << std::flush;
  } else if (command == "isready") {
    std::cout << "readyok\n" << std::flush;
  } else if (command == "ucinewgame") {
    initBoard(board);
  } else if (command == "position") {
    std::string token;
    input >> token;
    if (token == "startpos") {
      initBoard(board);
      if (!(input >> token) || token != "moves") {
        return;
      }
    } else if (token == "fen") {
      std::string fen;
      while (input >> token && token != "moves") {
        if (!fen.empty()) {
          fen += ' ';
        }
        fen += token;
      }
      loadFen(board, fen);
    } else {
      return;
    }

    while (input >> token) {
      applyMove(board, parseMove(token));
    }
  } else if (command == "go") {
    std::cout << "bestmove 0000\n" << std::flush;
  } else if (command == "d" || command == "display") {
    printBoard(board);
  }
  // "stop" and unrecognized commands need no action in Part 1.
}

