#include "board_io.h"
#include "uci.h"

#include <array>
#include <functional>
#include <iostream>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>

namespace {

const std::string startFen =
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

void require(bool condition, const std::string& message) {
  if (!condition) {
    throw std::runtime_error(message);
  }
}

class OutputCapture {
 public:
  OutputCapture() : previous(std::cout.rdbuf(output.rdbuf())) {}
  ~OutputCapture() { std::cout.rdbuf(previous); }
  std::string str() const { return output.str(); }

 private:
  std::ostringstream output;
  std::streambuf* previous;
};

std::string commandOutput(const std::string& command, Board& board) {
  OutputCapture capture;
  handleUciCommand(command, board);
  return capture.str();
}

void testBoard() {
  Board board;
  for (auto& row : board) {
    row.fill(Piece::WQueen);
  }
  initBoard(board);

  const std::array<Piece, 8> black{
      BRook, BKnight, BBishop, BQueen, BKing, BBishop, BKnight, BRook};
  const std::array<Piece, 8> white{
      WRook, WKnight, WBishop, WQueen, WKing, WBishop, WKnight, WRook};
  require(board[0] == black && board[7] == white, "Starting back ranks");
  for (int col = 0; col < 8; ++col) {
    require(board[1][col] == BPawn && board[6][col] == WPawn, "Pawn ranks");
    for (int row = 2; row < 6; ++row) {
      require(board[row][col] == Empty, "Middle ranks must be cleared");
    }
  }

  const Board beforePrinting = board;
  const std::string expected =
      "8 \u265c \u265e \u265d \u265b \u265a \u265d \u265e \u265c \n"
      "7 \u265f \u265f \u265f \u265f \u265f \u265f \u265f \u265f \n"
      "6 . . . . . . . . \n"
      "5 . . . . . . . . \n"
      "4 . . . . . . . . \n"
      "3 . . . . . . . . \n"
      "2 \u2659 \u2659 \u2659 \u2659 \u2659 \u2659 \u2659 \u2659 \n"
      "1 \u2656 \u2658 \u2657 \u2655 \u2654 \u2657 \u2658 \u2656 \n"
      "  a b c d e f g h\n";
  {
    OutputCapture capture;
    printBoard(board);
    require(capture.str() == expected, "Exact Unicode board output and spacing");
  }
  require(board == beforePrinting, "Printing must preserve the board");
}

void testPieces() {
  const std::array<Piece, 13> pieces{
      Empty, WPawn, WKnight, WBishop, WRook, WQueen, WKing,
      BPawn, BKnight, BBishop, BRook, BQueen, BKing};
  const std::string characters = ".PNBRQKpnbrqk";
  for (std::size_t i = 0; i < pieces.size(); ++i) {
    require(pieceToChar(pieces[i]) == characters[i], "Piece to character");
    require(charToPiece(characters[i]) == pieces[i], "Character to piece");
    const bool white = i >= 1 && i <= 6;
    const bool black = i >= 7;
    require(isWhitePiece(pieces[i]) == white, "White piece query");
    require(isBlackPiece(pieces[i]) == black, "Black piece query");
    const Color color = white ? Color::White : black ? Color::Black : Color::None;
    require(getPieceColor(pieces[i]) == color, "Piece color");
    for (std::size_t j = 0; j < pieces.size(); ++j) {
      const bool opponents =
          (white && j >= 7) || (black && j >= 1 && j <= 6);
      require(isOpponent(pieces[i], pieces[j]) == opponents, "Opponent query");
    }
  }
  for (char unknown : std::string("?x09 ")) {
    require(charToPiece(unknown) == Empty, "Unknown characters map to Empty");
  }
}

void testCoordinates() {
  require(stringToSquare("a8") == Square{0, 0}, "a8 is the top-left square");
  require(stringToSquare("h1") == Square{7, 7}, "h1 is the bottom-right square");
  require(stringToSquare("e2") == Square{6, 4}, "e2 coordinates");
  require(stringToSquare("e4") == Square{4, 4}, "e4 coordinates");
  for (int row = 0; row < 8; ++row) {
    for (int col = 0; col < 8; ++col) {
      const Square square{row, col};
      require(isValidSquare(square), "All 64 board squares are valid");
      require(stringToSquare(squareToString(square)) == square,
              "All 64 coordinate round trips");
    }
  }
  for (Square outside : {Square{-1, 0}, Square{0, -1}, Square{8, 0}, Square{0, 8}}) {
    require(!isValidSquare(outside), "Out-of-bounds square");
    require(squareToString(outside).empty(), "Invalid square formatting");
  }
  for (const std::string invalid : {"", "a", "a0", "i4", "a9", "e22"}) {
    require(!isValidSquare(stringToSquare(invalid)), "Invalid coordinate input");
  }
}

void testFen() {
  Board board;
  initBoard(board);
  require(boardToFen(board) == startFen, "Initial FEN");
  const Board initial = board;
  loadFen(board, "8/8/8/8/8/8/8/8");
  require(board == Board{}, "Loading empty FEN clears every square");
  loadFen(board, startFen + " w KQkq - 0 1");
  require(board == initial, "Full FEN uses only piece placement");

  for (const std::string fen : {
           "k7/8/8/3pP3/8/8/8/7K", "8/8/8/8/8/8/8/8",
           "r3k2r/1P6/2N5/3B4/4q3/5n2/6p1/R3K2R"}) {
    loadFen(board, fen);
    require(boardToFen(board) == fen, "Canonical FEN round trip");
  }

  std::mt19937 generator(2026);
  std::uniform_int_distribution<int> distribution(0, 12);
  for (int trial = 0; trial < 100; ++trial) {
    Board original;
    for (auto& row : original) {
      for (Piece& piece : row) {
        piece = static_cast<Piece>(distribution(generator));
      }
    }
    loadFen(board, boardToFen(original));
    require(board == original, "Random board FEN round trip");
  }

  const Board beforeInvalid = board;
  for (const std::string invalid : {
           "", "8/8/8/8/8/8/8", "8/8/8/8/8/8/8/9",
           "8/8/8/8/8/8/8/8/8", "8/8/8/8/8/8/8/7x", "8/8/8/8/8/8/8/8P"}) {
    loadFen(board, invalid);
    require(board == beforeInvalid, "Invalid FEN must not partially overwrite board");
  }
}

void testMoves() {
  const Move move = parseMove("e2e4");
  require(move == Move{Square{6, 4}, Square{4, 4}, Empty}, "Parse standard move");
  require(moveToString(move) == "e2e4", "Format standard move");
  Board board;
  initBoard(board);
  applyMove(board, move);
  require(board[6][4] == Empty && board[4][4] == WPawn, "Move and clear source");
  board[3][3] = BPawn;
  applyMove(board, parseMove("e4d5"));
  require(board[4][4] == Empty && board[3][3] == WPawn, "Capture overwrites target");

  const std::string promotions = "qrbn";
  const std::array<Piece, 4> white{WQueen, WRook, WBishop, WKnight};
  const std::array<Piece, 4> black{BQueen, BRook, BBishop, BKnight};
  for (std::size_t i = 0; i < promotions.size(); ++i) {
    const std::string whiteMove = "a7a8" + promotions.substr(i, 1);
    const std::string blackMove = "h2h1" + promotions.substr(i, 1);
    require(parseMove(whiteMove).promotion == black[i], "Parse lowercase promotion");
    require(moveToString(parseMove(whiteMove)) == whiteMove, "Promotion round trip");
    require(moveToString(Move{{1, 0}, {0, 0}, white[i]}) == whiteMove,
            "White promotion formatting is lowercase");
    board = {};
    board[1][0] = WPawn;
    board[0][0] = BRook;
    applyMove(board, parseMove(whiteMove));
    require(board[1][0] == Empty && board[0][0] == white[i], "White promotion color");
    board[6][7] = BPawn;
    board[7][7] = WRook;
    applyMove(board, parseMove(blackMove));
    require(board[6][7] == Empty && board[7][7] == black[i], "Black promotion color");
  }

  const Board beforeInvalid = board;
  for (const std::string invalid : {"", "e2", "e9e4", "e2e4qq", "e2e4p", "0000"}) {
    applyMove(board, parseMove(invalid));
    require(board == beforeInvalid, "Invalid moves must not access outside board");
  }
  applyMove(board, parseMove("a8a8"));
  require(board == beforeInvalid, "Same-square move preserves the piece");
}

void testUci() {
  Board board;
  initBoard(board);
  const std::string identification = commandOutput("uci", board);
  require(identification.starts_with("id name "), "UCI engine name");
  require(identification.find("\nid author ") != std::string::npos, "UCI author");
  require(identification.ends_with("uciok\n"), "UCI handshake acknowledgment");
  require(commandOutput("isready", board) == "readyok\n", "Readiness response");
  require(commandOutput("position startpos moves e2e4 e7e5 g1f3 b8c6", board).empty(),
          "Position setup has no protocol output");
  require(boardToFen(board) ==
              "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R",
          "Assignment's four-move example");
  {
    OutputCapture capture;
    printBoard(board);
    require(commandOutput("d", board) == capture.str(), "Debug board command");
    require(commandOutput("display", board) == capture.str(), "Display alias");
  }
  require(commandOutput("go depth 5", board) == "bestmove 0000\n", "Dummy best move");
  const Board beforeStop = board;
  require(commandOutput("stop", board).empty() && board == beforeStop, "Stop is a no-op");
  commandOutput("ucinewgame", board);
  require(boardToFen(board) == startFen, "New game resets the board");
  commandOutput("position startpos", board);
  require(boardToFen(board) == startFen, "Position without moves");
  commandOutput("position fen 8/P7/8/8/8/8/7p/8 w - - 0 1 moves a7a8q h2h1n", board);
  require(boardToFen(board) == "Q7/8/8/8/8/8/8/7n", "Full FEN and promotion sequence");
  commandOutput("position fen 8/8/8/8/8/8/8/8", board);
  require(board == Board{}, "Placement-only FEN command");
  commandOutput("position fen " + startFen + " b KQkq - 0 1", board);
  require(boardToFen(board) == startFen, "Full FEN without moves");
  for (const std::string unknown : {"", "   ", "unknown", "position nonsense"}) {
    require(commandOutput(unknown, board).empty(), "Unknown commands are ignored");
  }
}

}  // namespace

int main(int argc, char* argv[]) {
  try {
    require(argc == 2, "Supply a test group name");
    const std::string name = argv[1];
    const std::array<std::pair<std::string, std::function<void()>>, 6> tests{{
        {"board", testBoard}, {"pieces", testPieces}, {"coordinates", testCoordinates},
        {"fen", testFen}, {"moves", testMoves}, {"uci", testUci}}};
    for (const auto& [testName, test] : tests) {
      if (name == testName) {
        test();
        std::cout << name << " checks passed\n";
        return 0;
      }
    }
    throw std::runtime_error("Unknown test group: " + name);
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
